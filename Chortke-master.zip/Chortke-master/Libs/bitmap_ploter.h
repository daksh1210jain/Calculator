#ifndef BITMAP_PLOTER_H_ 
#define BITMAP_PLOTER_H_

void write_bitmap(char *plot, int width, int height, int axis_color,int screen_color, int plot_color, const char *filename);

#endif
