#ifndef STACK_H_ 
#define STACK_H_

void initial();
float pop_n();
void push_n(float x);// x : the number wanted to be pushed.
int get_i_n();

char pop_c();
void push_c(char x);//x : the number wanted to be pushed.
char get_top();
int get_i_c();
char show_last_c();

#endif
